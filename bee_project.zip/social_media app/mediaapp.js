const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');
const databaseUri = 'mongodb://localhost:27017/mydb';
const User=require('./model/user');
const Post=require('./model/post');
const updPosts=require('./routes/posts');
const application = express();
const port = 3004;
const session = require('express-session');

application.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false
}));
// Set up middleware

application.set('view engine', 'ejs');
application.use(cookieParser());
application.use(bodyParser.urlencoded({ extended: true }));
application.use(express.static('public'));

// Connect to MongoDB
async function db(){
    await mongoose.connect(databaseUri);
}
db()
.then(res=>console.log("DB connected"))
.catch(err=>console.log(`error ${err}`));
application.use((req,res,next)=>{
  const {auth} = req.cookies;
  if(auth){
     req.isAuthenticated = true;
  }else{
     req.isAuthenticated = false;
  }
  next();
 })
 const isAuthenticated = (req,res,next)=>{
     if(req.isAuthenticated){
         next();
     }else{
         res.status(401).redirect("/login");
     }
 }
 application.get("/",isAuthenticated,async (req,res)=>{
     try{
        const curruser = req.session.username;
         const posts = await Post.find({});
         res.render('home',{posts,curruser});
     }catch(error){
         console.log(error);
         res.status(500).render('home',{error:"Internal server error"})
     }
 })
 // Routing
 application.get("/logout",(req,res)=>{
     res.clearCookie("auth");
     res.status(200).redirect("/login");
 })
 
 application.get("/login",(req,res)=>{
     res.render('login');
 })
 
 application.get("/register",(req,res)=>{
     res.render('register',{"error":""});
 })
 
 application.post('/register',async (req,res)=>{
     console.log(req.body);
     const {username,password} = req.body;
     try{
         // check if the username and password is not empty
         if(!username || !password){
             res.status(401).render('register',{'error':"Enter username and password"})
         }
         const existingUser = await User.findOne({username});
         if(existingUser){
             res.status(400).render('register',{"error":"Username already exists"})
             return;
         }
         const hashedPassword = bcrypt.hashSync(password,10);
         const newUser = new User({
             username,
             password:hashedPassword
         })
         await newUser.save();
         res.status(201).redirect('/login');
     }catch(error){
         console.log(error);
         res.status(500).render('register',{'error':"Internal server error"})
     }
 })
 
 application.post('/login',async (req,res)=>{
     const {username,password} = req.body;
     req.session.username = username;
     try{
         const user = await User.findOne({username});
         if(user && bcrypt.compareSync(password,user.password)){
             res.cookie('auth',true);
             res.status(201).redirect('/');
         }else{
             res.status(500).render('login',{'error':"Incorrect username/password"})
         }
     }catch(error){
         console.log(error);
         res.status(500).render('login',{'error':"Internal server error"})
     }
 })
 
 application.use('/posts',updPosts);
// Start the server
application.listen(port, () => {
  console.log(`Media App is running on http://localhost:${port}`);
});
