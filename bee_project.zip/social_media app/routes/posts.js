// routes/posts.js
const express = require('express');
const router = express.Router();
const Post = require('../model/post');
const upload = require('express-fileupload');
router.use(upload()); // Enable file uploads for the router

router.get('/create', (req, res) => {
  const username = req.query.username;
  res.render('create', { username }); // Render the create form
});

router.post('/create', async (req, res) => {
  try {
    const { content } = req.body;
    let image;
    const username = req.session.username;

    // Use a different variable for post title
    const postTitle = username;

    // Check if the user provided an image file
    if (req.files && req.files.image_file) {
      // If a file is uploaded, save it and use its path as the image
      const uploadedImage = req.files.image_file;
      const imagePath = `/uploads/${Date.now()}_${uploadedImage.name}`;
      await uploadedImage.mv(`public${imagePath}`);
      image = imagePath;
    } else {
      // If an image URL is provided, use it
      image = req.body.image_url;
    }

    const newPost = new Post({ title: postTitle, content, image });
    await newPost.save();
    res.redirect('/'); // Redirect to the home page or wherever you want
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});
router.get('/edit',async (req,res)=>{
  const username = req.query.username;
  const posts = await Post.find({});
  res.render('edit',{username,posts});
});
module.exports = router;
